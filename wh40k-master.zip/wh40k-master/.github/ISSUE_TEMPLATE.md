**File/Catalogue:** 

**BattleScribe version:** 2.03.

**Platform:** Windows/iOS/Android/Mac/Linux

**Dropbox:** Yes/No

**Description:** Detailed issue description.
